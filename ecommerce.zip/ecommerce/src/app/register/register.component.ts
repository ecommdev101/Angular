import { Component } from '@angular/core';
import { UserService } from '../user.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-register',
  imports: [FormsModule,CommonModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {

  isRegSuccessful:boolean= false;

  constructor(private userService:UserService){
  
    }
     username:string = "";
     password:string = "";
  
     register(){
       let user = {
           username :this.username,
           password:this.password,
           role: "USER"
       }
       console.log("user", user);
  
        this.userService.registerUser(user).subscribe(
          {
            next: (response:any) => {
  
              console.log(response);

               this.isRegSuccessful = true;
            },
  
            error : (error:any) =>{
                console.log(error);
            },
  
            complete: () =>{
                  console.log("completed");
            }
          }
        )
  
     }

}
