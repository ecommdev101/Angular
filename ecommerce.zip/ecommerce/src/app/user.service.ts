import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpClient:HttpClient) { }

   loginUser(user:any){

     return this.httpClient.post("http://localhost:8086/login",user);

   }

   registerUser(user:any){

     return this.httpClient.post("http://localhost:8086/register",user);


   }

}
