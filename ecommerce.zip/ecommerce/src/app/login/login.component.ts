import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  constructor(private userService:UserService){

  }
   username:string = "";
   password:string = "";

   login(){
     let user = {
         username :this.username,
         password:this.password
     }
     console.log("user", user);

      this.userService.loginUser(user).subscribe(
        {
          next: (response:any) => {

            console.log(response);
          },

          error : (error:any) =>{
              console.log(error);
          },

          complete: () =>{
                console.log("completed");
          }
        }
      )

   }
}
